"""Main TorrentOS Settings window — sidebar + content area, libadwaita-style."""

from __future__ import annotations

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gio, GLib, Gtk  # noqa: E402

from .pages.appearance import AppearancePage
from .pages.accessibility import AccessibilityPage
from .pages.display import DisplayPage
from .pages.dev_mode import DevModePage
from .pages.about import AboutPage
from .settings import Settings


PAGES: list[tuple[str, str, str, type]] = [
    # (id, title, icon-name, page-class)
    ("appearance",     "Appearance",     "preferences-desktop-wallpaper-symbolic", AppearancePage),
    ("accessibility",  "Accessibility",  "preferences-desktop-accessibility-symbolic", AccessibilityPage),
    ("display",        "Display",        "video-display-symbolic",                  DisplayPage),
    ("dev_mode",       "Dev Mode",       "applications-development-symbolic",       DevModePage),
    ("about",          "About",          "help-about-symbolic",                     AboutPage),
]


class SettingsWindow(Adw.ApplicationWindow):
    def __init__(self, *, application: Adw.Application, settings: Settings) -> None:
        super().__init__(application=application)
        self.settings = settings
        self.set_title("TorrentOS Settings")
        self.set_default_size(900, 640)
        self.set_size_request(720, 520)

        # Layout: NavigationSplitView for the sidebar + content pane (macOS-feel).
        split = Adw.NavigationSplitView()
        split.set_min_sidebar_width(200)
        split.set_max_sidebar_width(280)
        split.set_sidebar_width_fraction(0.28)
        self.set_content(split)

        # ---- sidebar ----
        sidebar_page = Adw.NavigationPage()
        sidebar_page.set_title("Settings")

        sidebar_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)

        sidebar_header = Adw.HeaderBar()
        sidebar_header.add_css_class("flat")
        sidebar_box.append(sidebar_header)

        scroller = Gtk.ScrolledWindow()
        scroller.set_vexpand(True)
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        sidebar_box.append(scroller)

        self.list_box = Gtk.ListBox()
        self.list_box.add_css_class("navigation-sidebar")
        self.list_box.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.list_box.connect("row-selected", self._on_row_selected)
        scroller.set_child(self.list_box)

        sidebar_page.set_child(sidebar_box)
        split.set_sidebar(sidebar_page)

        # ---- content ----
        self.content_stack = Gtk.Stack()
        self.content_stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
        self.content_stack.set_transition_duration(180)

        content_page = Adw.NavigationPage()
        content_page.set_title("Settings")

        content_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        content_header = Adw.HeaderBar()
        content_header.add_css_class("flat")
        content_box.append(content_header)
        content_box.append(self.content_stack)
        content_page.set_child(content_box)
        split.set_content(content_page)

        # ---- populate ----
        self._page_instances: dict[str, Gtk.Widget] = {}
        for pid, title, icon, cls in PAGES:
            page_widget = cls(self.settings)
            self.content_stack.add_named(page_widget, pid)
            self._page_instances[pid] = page_widget

            row = Gtk.ListBoxRow()
            row.set_name(pid)
            hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
            hbox.set_margin_start(12)
            hbox.set_margin_end(12)
            hbox.set_margin_top(8)
            hbox.set_margin_bottom(8)
            img = Gtk.Image.new_from_icon_name(icon)
            img.set_pixel_size(20)
            hbox.append(img)
            label = Gtk.Label(label=title, xalign=0)
            label.set_hexpand(True)
            hbox.append(label)
            row.set_child(hbox)
            self.list_box.append(row)

        # Select first row by default
        first = self.list_box.get_row_at_index(0)
        if first:
            self.list_box.select_row(first)

    def _on_row_selected(self, _list_box: Gtk.ListBox, row: Gtk.ListBoxRow | None) -> None:
        if row is None:
            return
        self.content_stack.set_visible_child_name(row.get_name())
