"""TorrentOS Settings — main package."""

__version__ = "0.4.0"
__app_id__ = "org.torrentos.Settings"
