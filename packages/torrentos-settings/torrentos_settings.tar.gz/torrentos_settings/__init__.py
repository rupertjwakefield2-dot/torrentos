"""TorrentOS Settings — main package."""

__version__ = "0.3.0"
__app_id__ = "org.torrentos.Settings"
