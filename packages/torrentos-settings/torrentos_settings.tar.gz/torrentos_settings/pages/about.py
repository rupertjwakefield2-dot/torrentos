"""About — version, branding, credits."""

from __future__ import annotations

from pathlib import Path

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, GdkPixbuf, Gtk  # noqa: E402

from .. import __version__
from ..settings import Settings


VERSION_FILE = Path("/etc/torrentos/version")
LOGO_FILE = Path("/usr/share/torrentos/branding/logo.svg")


def _read_version_field(field: str, fallback: str = "?") -> str:
    if not VERSION_FILE.exists():
        return fallback
    for line in VERSION_FILE.read_text().splitlines():
        if line.startswith(f"{field}="):
            return line.split("=", 1)[1].strip().strip('"')
    return fallback


class AboutPage(Adw.PreferencesPage):
    def __init__(self, settings: Settings) -> None:
        super().__init__()
        self.settings = settings

        # Hero
        hero_group = Adw.PreferencesGroup()
        self.add(hero_group)

        hero = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        hero.set_margin_top(24)
        hero.set_margin_bottom(12)
        hero.set_halign(Gtk.Align.CENTER)

        if LOGO_FILE.exists():
            try:
                pic = Gtk.Picture.new_for_filename(str(LOGO_FILE))
                pic.set_size_request(120, 120)
                pic.set_can_shrink(True)
                hero.append(pic)
            except Exception:
                pass

        title = Gtk.Label(label="<span size='xx-large' weight='bold'>TorrentOS</span>")
        title.set_use_markup(True)
        hero.append(title)

        codename = _read_version_field("TORRENTOS_CODENAME", "Riptide")
        version = _read_version_field("TORRENTOS_VERSION", __version__)
        sub = Gtk.Label(label=f"{version} · {codename}")
        sub.add_css_class("dim-label")
        hero.append(sub)

        hero_group.add(hero)

        # Details
        details = Adw.PreferencesGroup()
        details.set_title("Details")
        self.add(details)

        for title_, value in [
            ("Channel",     _read_version_field("TORRENTOS_CHANNEL", "dev")),
            ("Codename",    codename),
            ("Settings UI", __version__),
            ("Architecture","x86_64"),
            ("Base",        "Arch Linux (rolling)"),
        ]:
            row = Adw.ActionRow()
            row.set_title(title_)
            row.set_subtitle(value)
            details.add(row)

        # Links
        links = Adw.PreferencesGroup()
        links.set_title("Resources")
        self.add(links)

        for title_, sub_, url in [
            ("Website",       "torrentos.org",                       "https://torrentos.org"),
            ("Documentation", "Setup, customization, troubleshooting","https://torrentos.org/docs"),
            ("Source code",   "GitHub",                              "https://github.com/torrentos/torrentos"),
            ("Report a bug",  "Issue tracker",                       "https://github.com/torrentos/torrentos/issues"),
        ]:
            row = Adw.ActionRow()
            row.set_title(title_)
            row.set_subtitle(sub_)
            btn = Gtk.LinkButton.new_with_label(url, "Open")
            btn.set_valign(Gtk.Align.CENTER)
            row.add_suffix(btn)
            links.add(row)
