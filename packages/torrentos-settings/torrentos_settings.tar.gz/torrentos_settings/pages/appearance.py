"""Appearance page — theme, accent, wallpaper."""

from __future__ import annotations

from pathlib import Path

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gio, Gtk  # noqa: E402

from .. import applier
from ..settings import Settings


THEMES = [
    ("light", "Light"),
    ("dark", "Dark"),
    ("auto", "Auto (follow system)"),
]

ACCENTS = [
    ("Torrent Blue",  "#1E6FFF"),
    ("Surge",         "#5BC0EB"),
    ("Riptide",       "#FF6B6B"),
    ("Foam Green",    "#5BEBA1"),
    ("Storm Purple",  "#C678DD"),
    ("Solar",         "#FFB454"),
]


class AppearancePage(Adw.PreferencesPage):
    def __init__(self, settings: Settings) -> None:
        super().__init__()
        self.settings = settings

        # ----- Theme group -----
        theme_group = Adw.PreferencesGroup()
        theme_group.set_title("Theme")
        theme_group.set_description("Light, dark, or system-driven appearance")
        self.add(theme_group)

        theme_row = Adw.ComboRow()
        theme_row.set_title("Color scheme")
        theme_model = Gtk.StringList()
        for _, label in THEMES:
            theme_model.append(label)
        theme_row.set_model(theme_model)
        current = settings.get("appearance.theme", "dark")
        theme_row.set_selected(next((i for i, (k, _) in enumerate(THEMES) if k == current), 1))
        theme_row.connect("notify::selected", self._on_theme_changed)
        theme_group.add(theme_row)

        # ----- Accent group -----
        accent_group = Adw.PreferencesGroup()
        accent_group.set_title("Accent color")
        accent_group.set_description("Tints buttons, focus rings, and Hyprland borders")
        self.add(accent_group)

        accent_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        accent_box.set_margin_top(8)
        accent_box.set_margin_bottom(8)
        accent_box.set_margin_start(12)
        accent_box.set_margin_end(12)
        accent_box.set_halign(Gtk.Align.START)

        current_accent = settings.get("appearance.accent", "#1E6FFF").lower()
        self._accent_buttons: list[Gtk.Button] = []
        for name, hex_color in ACCENTS:
            btn = self._make_accent_swatch(name, hex_color, selected=hex_color.lower() == current_accent)
            accent_box.append(btn)
            self._accent_buttons.append(btn)
        accent_group.add(accent_box)

        # ----- Wallpaper group -----
        wallpaper_group = Adw.PreferencesGroup()
        wallpaper_group.set_title("Wallpaper")
        self.add(wallpaper_group)

        current_wp = settings.get("appearance.wallpaper", "/usr/share/torrentos/branding/wallpaper.png")
        wp_row = Adw.ActionRow()
        wp_row.set_title("Current wallpaper")
        wp_row.set_subtitle(current_wp)
        wp_btn = Gtk.Button(label="Choose…")
        wp_btn.add_css_class("suggested-action")
        wp_btn.set_valign(Gtk.Align.CENTER)
        wp_btn.connect("clicked", self._on_wallpaper_clicked, wp_row)
        wp_row.add_suffix(wp_btn)
        wallpaper_group.add(wp_row)

        reset_row = Adw.ActionRow()
        reset_row.set_title("Reset to default")
        reset_row.set_subtitle("Use the shipped TorrentOS wallpaper")
        reset_btn = Gtk.Button(label="Reset")
        reset_btn.add_css_class("flat")
        reset_btn.set_valign(Gtk.Align.CENTER)
        reset_btn.connect("clicked", self._on_wallpaper_reset, wp_row)
        reset_row.add_suffix(reset_btn)
        wallpaper_group.add(reset_row)

    # ----- helpers -----

    def _make_accent_swatch(self, name: str, hex_color: str, *, selected: bool) -> Gtk.Button:
        btn = Gtk.Button()
        btn.set_size_request(36, 36)
        btn.set_tooltip_text(name)
        css = Gtk.CssProvider()
        css.load_from_data(
            f"button {{ background: {hex_color}; border-radius: 18px; "
            f"min-width: 36px; min-height: 36px; padding: 0; "
            f"box-shadow: {'inset 0 0 0 3px white, 0 0 0 2px ' + hex_color if selected else 'none'}; }}".encode()
        )
        btn.get_style_context().add_provider(css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        btn.connect("clicked", self._on_accent_clicked, hex_color)
        return btn

    # ----- handlers -----

    def _on_theme_changed(self, row: Adw.ComboRow, _pspec) -> None:
        idx = row.get_selected()
        key = THEMES[idx][0]
        self.settings.set("appearance.theme", key)
        applier.apply("appearance.theme", key)

    def _on_accent_clicked(self, _btn: Gtk.Button, hex_color: str) -> None:
        self.settings.set("appearance.accent", hex_color)
        applier.apply("appearance.accent", hex_color)
        # Re-render swatches to update selected ring
        for b in self._accent_buttons:
            b.unparent() if b.get_parent() else None  # no-op safety
        # Simpler: just leave visual state. Future: rebuild swatches.

    def _on_wallpaper_clicked(self, _btn: Gtk.Button, row: Adw.ActionRow) -> None:
        dialog = Gtk.FileDialog()
        dialog.set_title("Choose wallpaper")
        f = Gtk.FileFilter()
        f.set_name("Images")
        for ext in ("png", "jpg", "jpeg", "webp"):
            f.add_pattern(f"*.{ext}")
        filters = Gio.ListStore.new(Gtk.FileFilter)
        filters.append(f)
        dialog.set_filters(filters)
        dialog.open(self.get_root(), None, self._on_wallpaper_picked, row)

    def _on_wallpaper_picked(self, dialog: Gtk.FileDialog, result, row: Adw.ActionRow) -> None:
        try:
            file = dialog.open_finish(result)
        except Exception:
            return
        path = file.get_path()
        if not path:
            return
        self.settings.set("appearance.wallpaper", path)
        applier.apply("appearance.wallpaper", path)
        row.set_subtitle(path)

    def _on_wallpaper_reset(self, _btn: Gtk.Button, row: Adw.ActionRow) -> None:
        default = "/usr/share/torrentos/branding/wallpaper.png"
        self.settings.reset("appearance.wallpaper")
        applier.apply("appearance.wallpaper", default)
        row.set_subtitle(default)
