"""Display — night light, brightness."""

from __future__ import annotations

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gtk  # noqa: E402

from .. import applier
from ..settings import Settings


class DisplayPage(Adw.PreferencesPage):
    def __init__(self, settings: Settings) -> None:
        super().__init__()
        self.settings = settings

        # Night light
        nl_group = Adw.PreferencesGroup()
        nl_group.set_title("Night light")
        nl_group.set_description("Reduce blue light in the evening for easier reading")
        self.add(nl_group)

        nl_switch = Adw.SwitchRow()
        nl_switch.set_title("Enable night light")
        nl_switch.set_subtitle("Uses gammastep")
        nl_switch.set_active(bool(settings.get("display.night-light", False)))
        nl_switch.connect("notify::active", self._on_nl_toggled)
        nl_group.add(nl_switch)

        temp_row = Adw.SpinRow.new_with_range(2700, 6500, 100)
        temp_row.set_title("Color temperature")
        temp_row.set_subtitle("Lower is warmer (2700K candle, 6500K daylight)")
        temp_row.set_value(int(settings.get("display.night-light-temp", 4000)))
        temp_row.connect("notify::value", self._on_temp_changed)
        nl_group.add(temp_row)
        self._temp_row = temp_row
        self._nl_switch = nl_switch

    def _on_nl_toggled(self, row: Adw.SwitchRow, _pspec) -> None:
        v = row.get_active()
        self.settings.set("display.night-light", v)
        temp = int(self._temp_row.get_value())
        self.settings.set("display.night-light-temp", temp)
        applier.apply_night_light(v, temp)

    def _on_temp_changed(self, row: Adw.SpinRow, _pspec) -> None:
        temp = int(row.get_value())
        self.settings.set("display.night-light-temp", temp)
        if self._nl_switch.get_active():
            applier.apply_night_light(True, temp)
