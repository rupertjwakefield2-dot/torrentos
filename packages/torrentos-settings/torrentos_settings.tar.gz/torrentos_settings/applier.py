"""Apply settings changes to the live system.

Each function here knows how to push one setting domain into the actual
running configuration: GTK theme, Hyprland blur opts, hyprpaper wallpaper, etc.

Idempotent. Safe to call repeatedly.
"""

from __future__ import annotations

import os
import shlex
import subprocess
from pathlib import Path


def _run(cmd: list[str] | str, check: bool = False) -> int:
    """Run a command, log stderr if it fails. Returns exit code."""
    if isinstance(cmd, str):
        cmd = shlex.split(cmd)
    try:
        return subprocess.run(cmd, check=check, capture_output=True).returncode
    except Exception as e:  # pragma: no cover
        print(f"[applier] {cmd[0]} failed: {e}")
        return 1


# ---------- appearance ----------

def apply_theme(theme: str) -> None:
    """theme: 'light' | 'dark' | 'auto'."""
    pref = "prefer-dark" if theme == "dark" else "prefer-light" if theme == "light" else "default"
    _run(["gsettings", "set", "org.gnome.desktop.interface", "color-scheme", pref])
    gtk_theme = "TorrentOS-Dark" if theme == "dark" else "TorrentOS-Light"
    _run(["gsettings", "set", "org.gnome.desktop.interface", "gtk-theme", gtk_theme])


def apply_accent(hex_color: str) -> None:
    """Update Hyprland border color via hyprctl. Format: '#RRGGBB' or 'RRGGBB'."""
    h = hex_color.lstrip("#").lower()
    if len(h) != 6:
        return
    _run(f"hyprctl keyword general:col.active_border rgba({h}ff)")


def apply_wallpaper(path: str) -> None:
    if not Path(path).exists():
        return
    _run(["hyprctl", "hyprpaper", "preload", path])
    _run(["hyprctl", "hyprpaper", "wallpaper", f",{path}"])


# ---------- accessibility ----------

def apply_high_contrast(enabled: bool) -> None:
    name = "HighContrast" if enabled else "TorrentOS-Dark"
    _run(["gsettings", "set", "org.gnome.desktop.interface", "gtk-theme", name])


def apply_screen_reader(enabled: bool) -> None:
    if enabled:
        _run("systemctl --user start orca.service", check=False)
        _run(["gsettings", "set", "org.gnome.desktop.a11y.applications", "screen-reader-enabled", "true"])
    else:
        _run("systemctl --user stop orca.service", check=False)
        _run(["gsettings", "set", "org.gnome.desktop.a11y.applications", "screen-reader-enabled", "false"])


def apply_ui_scale(scale: float) -> None:
    """1.0 / 1.25 / 1.5 / 2.0"""
    _run(f"hyprctl keyword monitor ,preferred,auto,{scale}")


def apply_sticky_keys(enabled: bool) -> None:
    val = "true" if enabled else "false"
    _run(["gsettings", "set", "org.gnome.desktop.a11y.keyboard", "stickykeys-enable", val])


# ---------- display ----------

def apply_night_light(enabled: bool, temp: int = 4000) -> None:
    """Use gammastep — already shipped."""
    _run("pkill -f gammastep || true")
    if enabled:
        # Detached so it survives this process exiting
        subprocess.Popen(
            ["gammastep", "-O", str(temp)],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            start_new_session=True,
        )


# ---------- dispatch ----------

DISPATCH = {
    "appearance.theme":         lambda v: apply_theme(v),
    "appearance.accent":        lambda v: apply_accent(v),
    "appearance.wallpaper":     lambda v: apply_wallpaper(v),
    "accessibility.high-contrast":  lambda v: apply_high_contrast(bool(v)),
    "accessibility.screen-reader":  lambda v: apply_screen_reader(bool(v)),
    "accessibility.ui-scale":   lambda v: apply_ui_scale(float(v)),
    "accessibility.sticky-keys":lambda v: apply_sticky_keys(bool(v)),
    "display.night-light":      lambda v: apply_night_light(bool(v)),
}


def apply(key: str, value) -> None:
    fn = DISPATCH.get(key)
    if fn:
        fn(value)
