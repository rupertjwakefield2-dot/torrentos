"""TorrentOS Settings — Adw.Application entry point."""

from __future__ import annotations

import sys

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gio, Gtk  # noqa: E402

from . import __app_id__, __version__
from .settings import Settings
from .window import SettingsWindow


class TorrentOSSettingsApp(Adw.Application):
    def __init__(self) -> None:
        super().__init__(
            application_id=__app_id__,
            flags=Gio.ApplicationFlags.FLAGS_NONE,
        )
        self.settings = Settings()
        self.connect("activate", self._on_activate)

    def _on_activate(self, app: Adw.Application) -> None:
        win = self.props.active_window
        if not win:
            win = SettingsWindow(application=self, settings=self.settings)
        win.present()


def main() -> int:
    app = TorrentOSSettingsApp()
    return app.run(sys.argv)


if __name__ == "__main__":
    raise SystemExit(main())
